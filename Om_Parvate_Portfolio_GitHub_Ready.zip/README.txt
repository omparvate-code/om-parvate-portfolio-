OM PARVATE PORTFOLIO — GITHUB PAGES READY

Files included:
- index.html
- style.css
- script.js
- assets/om-parvate.jpg
- assets/Om_Ramakant_Parvate_Resume.pdf

Upload/extract these files so index.html is at the repository root.
The HTML currently links to the resume using Google Drive links; the local PDF is preserved in assets as requested.
